import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { UserRole, Gender } from '../types';
import { toast } from 'sonner';
import { motion } from 'motion/react';

export const Onboarding: React.FC = () => {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState<UserRole>('Independent Seeker');
  const [gender, setGender] = useState<Gender>('male');
  const [displayName, setDisplayName] = useState('');
  const [requiresParentalVetting, setRequiresParentalVetting] = useState(false);
  const [parentUid, setParentUid] = useState('');
  const navigate = useNavigate();

  const handleGoogleSignIn = async () => {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Check if profile exists
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        navigate('/feed');
      } else {
        setDisplayName(user.displayName || '');
        setStep(2);
      }
    } catch (error) {
      console.error(error);
      toast.error("Failed to sign in");
    }
  };

  const handleSubmit = async () => {
    if (!auth.currentUser) return;

    try {
      await setDoc(doc(db, 'users', auth.currentUser.uid), {
        uid: auth.currentUser.uid,
        email: auth.currentUser.email,
        displayName,
        role,
        gender: role === 'Parent/Guardian' ? undefined : gender,
        requiresParentalVetting: role === 'Independent Seeker' && gender === 'male' ? requiresParentalVetting : false,
        parentUid: role === 'Dependent Seeker' ? parentUid : undefined,
        isIntroCompleted: false,
        createdAt: new Date().toISOString(),
      });

      toast.success("Profile created!");
      navigate('/readiness');
    } catch (error) {
      console.error(error);
      toast.error("Failed to save profile");
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4 bg-slate-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {step === 1 ? (
          <Card className="border-none shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold text-rose-600">Welcome to NikahPath</CardTitle>
              <CardDescription>Begin your journey towards a Halal union</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-slate-600 text-center">
                NikahPath is an intentional matchmaking platform built on Islamic principles of modesty, privacy, and family involvement.
              </p>
              <Button onClick={handleGoogleSignIn} className="w-full py-6 text-lg" variant="outline">
                Continue with Google
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-none shadow-xl">
            <CardHeader>
              <CardTitle>Complete Your Profile</CardTitle>
              <CardDescription>Tell us about your role in the matchmaking process</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Enter your name" />
              </div>

              <div className="space-y-2">
                <Label>Your Role</Label>
                <Select value={role} onValueChange={(v) => setRole(v as UserRole)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Independent Seeker">Independent Seeker</SelectItem>
                    <SelectItem value="Dependent Seeker">Dependent Seeker (Wali Involved)</SelectItem>
                    <SelectItem value="Parent/Guardian">Parent/Guardian</SelectItem>
                    <SelectItem value="Mahram">Mahram (Chaperone)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {role !== 'Parent/Guardian' && (
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <Select value={gender} onValueChange={(v) => setGender(v as Gender)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              {role === 'Independent Seeker' && gender === 'male' && (
                <div className="flex items-center justify-between p-4 bg-rose-50 rounded-lg border border-rose-100">
                  <div className="space-y-0.5">
                    <Label className="text-rose-900">Parental Vetting</Label>
                    <p className="text-xs text-rose-700">Require parent approval before matches see your profile</p>
                  </div>
                  <Switch checked={requiresParentalVetting} onCheckedChange={setRequiresParentalVetting} />
                </div>
              )}

              {role === 'Dependent Seeker' && (
                <div className="space-y-2">
                  <Label>Parent/Wali Email or UID</Label>
                  <Input value={parentUid} onChange={(e) => setParentUid(e.target.value)} placeholder="Enter their identifier" />
                  <p className="text-xs text-slate-500">This allows your Wali to manage your connections.</p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleSubmit} className="w-full bg-rose-600 hover:bg-rose-700 text-white py-6">
                Complete Setup
              </Button>
            </CardFooter>
          </Card>
        )}
      </motion.div>
    </div>
  );
};
