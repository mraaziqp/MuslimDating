import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import { Connection, UserProfile } from '../types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Check, X, ShieldAlert, UserCheck } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

export const ParentDashboard: React.FC = () => {
  const { profile } = useAuth();
  const [pendingApprovals, setPendingApprovals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile || profile.role !== 'Parent/Guardian') return;

    // Find connections where the sender or receiver is a dependent of this parent
    // For simplicity, we'll query connections where status is 'pending_parent_approval'
    const q = query(
      collection(db, 'connections'),
      where('status', '==', 'pending_parent_approval'),
      where('parentApprovalStatus', '==', 'pending')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const connections = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Connection));
      
      const enriched = await Promise.all(connections.map(async (conn) => {
        const senderSnap = await getDoc(doc(db, 'users', conn.senderUid));
        const receiverSnap = await getDoc(doc(db, 'users', conn.receiverUid));
        
        const sender = senderSnap.data() as UserProfile;
        const receiver = receiverSnap.data() as UserProfile;

        // Only show if this parent is the parent of either the sender or receiver
        if (sender.parentUid === profile.uid || receiver.parentUid === profile.uid) {
          return { ...conn, sender, receiver };
        }
        return null;
      }));

      setPendingApprovals(enriched.filter(Boolean));
      setLoading(false);
    });

    return () => unsubscribe();
  }, [profile]);

  const handleApproval = async (connectionId: string, approved: boolean) => {
    try {
      const connRef = doc(db, 'connections', connectionId);
      if (approved) {
        await updateDoc(connRef, {
          parentApprovalStatus: 'approved',
          status: 'pending_receiver_approval',
          updatedAt: new Date().toISOString()
        });
        toast.success("Match approved and forwarded.");
      } else {
        await updateDoc(connRef, {
          parentApprovalStatus: 'declined',
          status: 'declined',
          updatedAt: new Date().toISOString()
        });
        toast.error("Match declined.");
      }
    } catch (error) {
      console.error(error);
      toast.error("Action failed.");
    }
  };

  if (loading) return <div className="p-8 text-center">Loading dashboard...</div>;

  return (
    <div className="max-w-5xl mx-auto p-4 space-y-8">
      <header className="flex justify-between items-end">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold text-slate-900">Guardian Dashboard</h1>
          <p className="text-slate-600">Review and vet potential matches for your family members.</p>
        </div>
        <Badge variant="secondary" className="bg-rose-100 text-rose-700 hover:bg-rose-100">
          <ShieldAlert className="h-4 w-4 mr-1" />
          Active Vetting
        </Badge>
      </header>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="pending">Pending Review ({pendingApprovals.length})</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-6">
          {pendingApprovals.length === 0 ? (
            <Card className="border-dashed border-2 bg-slate-50">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <UserCheck className="h-12 w-12 text-slate-300 mb-4" />
                <p className="text-slate-500 font-medium">No pending match requests to review.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-6">
              {pendingApprovals.map((conn) => (
                <Card key={conn.id} className="overflow-hidden border-none shadow-md">
                  <div className="flex flex-col md:flex-row">
                    <div className="p-6 flex-1 space-y-4">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-16 w-16 border-2 border-rose-100">
                          <AvatarImage src={conn.sender.photoUrl} />
                          <AvatarFallback>{conn.sender.displayName[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-lg font-bold text-slate-900">{conn.sender.displayName}</h3>
                          <p className="text-sm text-slate-500">Requesting to connect with your dependent</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold mb-1">Profession</p>
                          <p className="text-sm font-bold text-slate-700">{conn.sender.profession || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold mb-1">Location</p>
                          <p className="text-sm font-bold text-slate-700">{conn.sender.location || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold mb-1">Prayer</p>
                          <p className="text-sm font-bold text-slate-700">{conn.sender.prayerFrequency || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold mb-1">Diet</p>
                          <p className="text-sm font-bold text-slate-700">{conn.sender.dietaryHabits || 'N/A'}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold mb-1">Readiness</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {conn.sender.completedModules?.map((m: string) => (
                              <Badge key={m} variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-100">
                                {m}
                              </Badge>
                            )) || <span className="text-[10px] text-slate-400">No modules completed</span>}
                          </div>
                        </div>
                        <div className="col-span-2">
                          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold mb-1">Bio</p>
                          <p className="text-xs text-slate-600 italic leading-relaxed">"{conn.sender.bio || 'No bio provided'}"</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-100 p-6 flex flex-col justify-center space-y-3 md:w-48">
                      <Button 
                        onClick={() => handleApproval(conn.id, true)}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                      >
                        <Check className="h-4 w-4 mr-2" />
                        Approve
                      </Button>
                      <Button 
                        onClick={() => handleApproval(conn.id, false)}
                        variant="outline" 
                        className="w-full border-rose-200 text-rose-600 hover:bg-rose-50"
                      >
                        <X className="h-4 w-4 mr-2" />
                        Decline
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="history">
          <div className="p-12 text-center text-slate-400">
            Historical vetting records will appear here.
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
