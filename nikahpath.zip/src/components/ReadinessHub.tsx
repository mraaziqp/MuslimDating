import React, { useState } from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { BookOpen, CheckCircle2, PlayCircle, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'motion/react';

const MODULES = [
  {
    id: 'intro',
    title: 'Etiquette of Halal Courtship',
    description: 'Learn the foundational principles of Islamic interaction and boundaries.',
    duration: '15 mins',
    required: true
  },
  {
    id: 'wali',
    title: 'The Role of the Wali',
    description: 'Understanding the wisdom behind familial involvement in marriage.',
    duration: '10 mins',
    required: false
  },
  {
    id: 'finance',
    title: 'Financial Responsibilities',
    description: 'A guide to Mahr and household management in Islam.',
    duration: '20 mins',
    required: false
  }
];

export const ReadinessHub: React.FC = () => {
  const { profile } = useAuth();
  const [completing, setCompleting] = useState(false);

  const handleCompleteModule = async (moduleId: string) => {
    if (!profile) return;
    if (moduleId !== 'intro') {
      toast.info("This module is optional but recommended!");
      return;
    }

    setCompleting(true);
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        isIntroCompleted: true
      });
      toast.success("Module completed! You can now send connection requests.");
    } catch (error) {
      console.error(error);
      toast.error("Failed to update progress.");
    } finally {
      setCompleting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <header className="text-center space-y-2 py-8">
        <h1 className="text-4xl font-bold text-slate-900 tracking-tight">Marriage Readiness Hub</h1>
        <p className="text-slate-600 max-w-2xl mx-auto">
          Equip yourself with the knowledge and etiquette required for a successful, blessed union.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-6">
        {MODULES.map((module, index) => (
          <motion.div
            key={module.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className={`border-none shadow-md ${module.id === 'intro' && !profile?.isIntroCompleted ? 'ring-2 ring-rose-500/20' : ''}`}>
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <CardTitle className="text-xl">{module.title}</CardTitle>
                    {module.required && <Badge variant="destructive" className="bg-rose-100 text-rose-600 border-none">Required</Badge>}
                  </div>
                  <CardDescription>{module.description}</CardDescription>
                </div>
                <div className="bg-slate-100 p-3 rounded-full">
                  <BookOpen className="h-6 w-6 text-slate-600" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-slate-500">
                  <PlayCircle className="h-4 w-4 mr-1" />
                  {module.duration}
                </div>
              </CardContent>
              <CardFooter className="bg-slate-50/50 border-t flex justify-between items-center py-4">
                {module.id === 'intro' && profile?.isIntroCompleted ? (
                  <div className="flex items-center text-emerald-600 font-medium">
                    <CheckCircle2 className="h-5 w-5 mr-2" />
                    Completed
                  </div>
                ) : (
                  <Button 
                    onClick={() => handleCompleteModule(module.id)}
                    disabled={completing}
                    className={module.id === 'intro' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-slate-800 hover:bg-slate-900'}
                  >
                    Start Module
                  </Button>
                )}
                
                {module.id !== 'intro' && !profile?.isIntroCompleted && (
                  <div className="flex items-center text-xs text-slate-400">
                    <Lock className="h-3 w-3 mr-1" />
                    Unlock after Intro
                  </div>
                )}
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
