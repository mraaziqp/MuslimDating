import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, doc, getDocs, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthProvider';
import { UserProfile } from '../types';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, ShieldCheck, Lock, BookOpen, Heart, Info, Sparkles, Briefcase, Clock, Utensils } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { seedMockData } from '../lib/mockData';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';

export const SeekerFeed: React.FC = () => {
  const { profile } = useAuth();
  const [seekers, setSeekers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showLimitModal, setShowLimitModal] = useState(false);

  useEffect(() => {
    if (!profile) return;

    const oppositeGender = profile.gender === 'male' ? 'female' : 'male';
    const q = query(
      collection(db, 'users'),
      where('gender', '==', oppositeGender),
      where('role', 'in', ['Independent Seeker', 'Dependent Seeker']),
      limit(5) // Curated batch of 5
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs
        .map(doc => doc.data() as UserProfile)
        .filter(s => s.uid !== profile.uid);
      setSeekers(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [profile]);

  const handleConnect = async (targetUser: UserProfile) => {
    if (!profile) return;

    if (!profile.isIntroCompleted) {
      toast.error("Please complete the Marriage Readiness module first!");
      return;
    }

    try {
      // Check active chats limit (max 3)
      const activeChatsQuery = query(
        collection(db, 'connections'),
        where('status', '==', 'approved'),
        where('senderUid', '==', profile.uid)
      );
      const activeChatsSnap = await getDocs(activeChatsQuery);
      
      if (activeChatsSnap.size >= 3) {
        setShowLimitModal(true);
        return;
      }
      
      const status = targetUser.role === 'Dependent Seeker' || (profile.gender === 'male' && profile.requiresParentalVetting)
        ? 'pending_parent_approval'
        : 'pending_receiver_approval';

      await addDoc(collection(db, 'connections'), {
        senderUid: profile.uid,
        receiverUid: targetUser.uid,
        status,
        parentApprovalStatus: status === 'pending_parent_approval' ? 'pending' : 'approved',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      const routingMsg = status === 'pending_parent_approval' 
        ? `Request sent to ${targetUser.displayName}'s Wali for approval`
        : `Request sent directly to ${targetUser.displayName}`;
      
      toast.success(routingMsg);
    } catch (error) {
      console.error(error);
      toast.error("Failed to send request");
    }
  };

  const handleSeed = async () => {
    const success = await seedMockData();
    if (success) toast.success("Mock data seeded!");
  };

  if (loading) return <div className="p-8 text-center">Curating your daily batch...</div>;

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <header className="flex justify-between items-center">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-rose-500" />
            Daily Curated Batch
          </h1>
          <p className="text-slate-600">Intentional connections based on shared values and readiness.</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleSeed} className="text-xs">
          Seed Mock Data
        </Button>
      </header>

      {seekers.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-200">
          <Heart className="h-12 w-12 text-slate-200 mx-auto mb-4" />
          <p className="text-slate-500">No new profiles in your batch today. Check back tomorrow!</p>
        </div>
      ) : (
        <div className="flex flex-col gap-12 max-w-2xl mx-auto">
          {seekers.map((seeker, index) => (
            <motion.div
              key={seeker.uid}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden border-none shadow-2xl bg-white flex flex-col">
                {/* Visual Header - MODESTY FIRST */}
                <div className="relative h-48 bg-slate-900 overflow-hidden">
                  <img 
                    src={seeker.photoUrl || `https://picsum.photos/seed/${seeker.uid}/800/400`} 
                    className="w-full h-full object-cover blur-3xl opacity-40 grayscale"
                    alt="Profile Background"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-transparent to-white/10">
                    <div className="bg-white/10 backdrop-blur-md p-3 rounded-full mb-3">
                      <Lock className="h-8 w-8 text-white/80" />
                    </div>
                    <Badge className="bg-rose-500 text-white border-none shadow-lg px-4 py-1">
                      {Math.abs(2026 - (new Date(seeker.createdAt).getFullYear())) > 0 ? 'Verified Profile' : 'New Member'}
                    </Badge>
                  </div>
                </div>

                <div className="p-8 -mt-6 bg-white rounded-t-3xl relative z-10 space-y-8">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">{seeker.displayName}</h3>
                      <div className="flex items-center text-slate-400 gap-4 text-sm font-medium">
                        <span className="flex items-center"><MapPin className="h-4 w-4 mr-1.5" /> {seeker.location || 'Global'}</span>
                        <span className="flex items-center"><Briefcase className="h-4 w-4 mr-1.5" /> {seeker.profession || 'Professional'}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-4xl font-black text-rose-500/10 block leading-none">{seeker.age}</span>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Years Old</span>
                    </div>
                  </div>

                  {/* DEEN METRICS - THE REAL COMPATIBILITY */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100/50">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-4 w-4 text-rose-500" />
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Prayer Frequency</span>
                      </div>
                      <p className="text-sm font-bold text-slate-800">{seeker.prayerFrequency || 'Not specified'}</p>
                    </div>
                    <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100/50">
                      <div className="flex items-center gap-2 mb-2">
                        <Utensils className="h-4 w-4 text-rose-500" />
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Dietary Habits</span>
                      </div>
                      <p className="text-sm font-bold text-slate-800">{seeker.dietaryHabits || 'Not specified'}</p>
                    </div>
                  </div>

                  {/* Readiness Badges */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        <ShieldCheck className="h-4 w-4 text-emerald-500" />
                        Readiness Certifications
                      </h4>
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                        {seeker.completedModules?.length || 0} Modules
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {seeker.completedModules?.map(m => (
                        <div key={m} className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50/50 border border-emerald-100 rounded-full text-[11px] font-bold text-emerald-700">
                          <BookOpen className="h-3.5 w-3.5" />
                          {m.charAt(0).toUpperCase() + m.slice(1)}
                        </div>
                      )) || <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-xl w-full text-center">Foundational modules in progress...</p>}
                    </div>
                  </div>

                  <div className="flex flex-col gap-4 pt-6 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs font-bold px-1">
                      <div className="flex items-center text-slate-400">
                        <Info className="h-4 w-4 mr-2" />
                        {seeker.role} Approval Workflow Required
                      </div>
                      <Sparkles className="h-4 w-4 text-rose-300" />
                    </div>
                    <Button 
                      onClick={() => handleConnect(seeker)}
                      className="w-full bg-slate-900 hover:bg-black text-white h-14 rounded-2xl shadow-2xl shadow-slate-200 text-base font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
                    >
                      Express Intent to Connect
                    </Button>
                    <p className="text-[10px] text-center text-slate-400 px-8">
                      By clicking, your profile values will be shared. Photos remain locked until mutual consent in a chaperoned chat.
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
          
          <div className="text-center py-12 space-y-4">
             <Heart className="h-8 w-8 text-rose-200 mx-auto" />
             <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">End of Daily Batch</p>
             <p className="text-xs text-slate-500 max-w-xs mx-auto">
               We limit your daily view to encourage mindful consideration over mindless scrolling.
             </p>
          </div>
        </div>
      )}

      {/* Intent Limit Modal */}
      <Dialog open={showLimitModal} onOpenChange={setShowLimitModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-slate-900">Intentionality Limit</DialogTitle>
            <DialogDescription className="text-slate-600 pt-2">
              To maintain focus and sincerity, NikahPath limits active conversations to 3 per seeker.
            </DialogDescription>
          </DialogHeader>
          <div className="py-6 flex flex-col items-center text-center space-y-4">
            <div className="h-16 w-16 bg-rose-50 rounded-full flex items-center justify-center">
              <Lock className="h-8 w-8 text-rose-500" />
            </div>
            <p className="text-sm text-slate-500">
              You currently have 3 active chats. Please conclude or close an existing conversation before initiating a new one.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowLimitModal(false)} className="w-full bg-slate-900 text-white">
              View My Chats
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

