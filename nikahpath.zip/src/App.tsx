import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './components/AuthProvider';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { Onboarding } from './components/Onboarding';
import { SeekerFeed } from './components/SeekerFeed';
import { ParentDashboard } from './components/ParentDashboard';
import { ReadinessHub } from './components/ReadinessHub';
import { ChatList } from './components/ChatList';
import { ChatRoom } from './components/ChatRoom';
import { Toaster } from './components/ui/sonner';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/onboarding" />;
  return <>{children}</>;
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-slate-50 font-sans antialiased">
            <Navbar />
            <main>
              <Routes>
                <Route path="/" element={<LandingPage />} />
                <Route path="/onboarding" element={<Onboarding />} />
                
                <Route path="/feed" element={
                  <ProtectedRoute>
                    <SeekerFeed />
                  </ProtectedRoute>
                } />
                
                <Route path="/parent-dashboard" element={
                  <ProtectedRoute>
                    <ParentDashboard />
                  </ProtectedRoute>
                } />
                
                <Route path="/readiness" element={
                  <ProtectedRoute>
                    <ReadinessHub />
                  </ProtectedRoute>
                } />
                
                <Route path="/chats" element={
                  <ProtectedRoute>
                    <ChatList />
                  </ProtectedRoute>
                } />
                
                <Route path="/chat/:connectionId" element={
                  <ProtectedRoute>
                    <ChatRoom />
                  </ProtectedRoute>
                } />
              </Routes>
            </main>
            <Toaster position="top-center" />
          </div>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}
